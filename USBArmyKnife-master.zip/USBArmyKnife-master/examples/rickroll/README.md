# Example - Rick roll

This DuckyScript payload is designed to deliver the ultimate Rick Roll experience. It opens a web browser, navigates to the classic Rick Roll video, uses an ESP32 Marauder to broadcast the lyrics over WiFi, and displays Rick Astley’s iconic image on an LCD screen.

**Note** The images to be displayed have been developed for the smallest screen supported. If you are using a device with a larger screen you will encounter unfilled areas of the display.

https://github.com/user-attachments/assets/f373e18e-5cad-4871-9f2a-17523fa33398

## Set up
1. Copy autorun.ds onto the SD card
2. Copy all the PNG files onto the SD card

## Usage
1. Plug in device
