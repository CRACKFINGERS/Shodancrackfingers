# Example - Hot Mic
The M5Stack AtomS3U has a SPM1423 PDM microphone included. If you are running this device then there is no Ducky support as the device itself contains no SD card to save the data to. If you want to use this device, connect to the web interface and navigate to the Microphone tab.

https://github.com/user-attachments/assets/035b0cde-a166-4661-9f13-715c95e007f0

