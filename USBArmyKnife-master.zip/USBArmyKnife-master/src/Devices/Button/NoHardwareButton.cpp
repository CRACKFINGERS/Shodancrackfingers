#ifdef NO_BUTTON
#include "HardwareButton.h"

namespace Devices
{
    HardwareButton Button;
}

HardwareButton::HardwareButton()
{
}

void HardwareButton::loop(Preferences& prefs)
{
}

void HardwareButton::begin(Preferences &prefs)
{
}

#endif