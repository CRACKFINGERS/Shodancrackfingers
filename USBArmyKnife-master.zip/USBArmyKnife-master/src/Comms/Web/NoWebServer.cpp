#ifdef NO_WEB
#include "WebServer.h"

namespace Comms
{
    WebSite Web;
}

WebSite::WebSite()
{
}

void WebSite::begin(Preferences &prefs)
{
}

void WebSite::loop(Preferences &prefs)
{

}

void WebSite::end()
{
}

#endif